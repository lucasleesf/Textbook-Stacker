#ifndef AVATAR_H
#define AVATAR_H
#include<iostream>
#include<QPaintEvent>
#include<QWidget>
#include<string>


//class avatar : public QWidget{
//    Q_OBJECT

//public:
//    avatar() : score(0), name("") {}
//    avatar(std::string user_name) :score(0), name(user_name) {}
//    virtual ~avatar() {};

//public slots:
//    void paintEvent(QPaintEvent *) override;

//signals:


//private:
//    size_t score;
//    std::string name;
    //QPixMap stationary;
//    QPixMap moveright;
//    QPixMap moveleft;


//};

//qgraphicsitem , qgraphicsscene
//Qpixmap private member variables


#endif // AVATAR_H
