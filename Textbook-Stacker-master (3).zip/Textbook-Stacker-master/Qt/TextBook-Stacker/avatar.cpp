
#include "avatar.h"



//void avatar::paintEvent(QPaintEvent *e) {

//}
